//go:build !linux && !darwin

package main

func earlyInitHook() {
}
