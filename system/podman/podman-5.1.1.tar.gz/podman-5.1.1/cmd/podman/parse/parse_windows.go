package parse

func ValidateFileName(filename string) error {
	return nil
}
