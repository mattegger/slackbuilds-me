####> This option file is used in:
####>   podman manifest add, manifest annotate
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--os-version**=*version*

Specify the OS version which the list or index records as a requirement for the
image.  This option is rarely used.
