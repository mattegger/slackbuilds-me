####> This option file is used in:
####>   podman manifest push, push
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--digestfile**=*Digestfile*

After copying the image, write the digest of the resulting image to the file.
