####> This option file is used in:
####>   podman create, exec, run, start
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--interactive**, **-i**

When set to **true**, keep stdin open even if not attached. The default is **false**.
