####> This option file is used in:
####>   podman create, run
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--dns-option**=*option*

Set custom DNS options. Invalid if using **--dns-option** with **--network** that is set to **none** or **container:**_id_.
