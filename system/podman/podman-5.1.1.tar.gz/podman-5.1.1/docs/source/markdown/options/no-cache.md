####> This option file is used in:
####>   podman build, farm build
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--no-cache**

Do not use existing cached images for the container build. Build from the start with a new set of cached layers.
