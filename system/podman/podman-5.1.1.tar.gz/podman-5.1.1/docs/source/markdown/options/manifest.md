####> This option file is used in:
####>   podman build
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--manifest**=*manifest*

Name of the manifest list to which the image is added. Creates the manifest list if it does not exist. This option is useful for building multi architecture images.
