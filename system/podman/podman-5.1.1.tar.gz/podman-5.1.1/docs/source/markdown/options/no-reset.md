####> This option file is used in:
####>   podman pod stats, stats
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--no-reset**

Do not clear the terminal/screen in between reporting intervals
