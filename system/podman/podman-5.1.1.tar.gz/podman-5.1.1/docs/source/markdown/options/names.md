####> This option file is used in:
####>   podman logs, pod logs
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--names**, **-n**

Output the container names instead of the container IDs in the log.
