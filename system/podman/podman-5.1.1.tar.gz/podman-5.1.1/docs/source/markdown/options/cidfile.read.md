####> This option file is used in:
####>   podman kill, pause, rm, stop, unpause
####> If file is edited, make sure the changes
####> are applicable to all of those.
#### **--cidfile**=*file*

Read container ID from the specified *file* and <<subcommand>> the container.
Can be specified multiple times.
