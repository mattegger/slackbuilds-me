.. include:: includes.rst

Reference
=========

Show the API documentation for version:

* `latest (main branch) <_static/api.html>`_

* `version 5.0 <_static/api.html?version=v5.0>`_

* `version 4.9 <_static/api.html?version=v4.9>`_

* `version 4.8 <_static/api.html?version=v4.8>`_

* `version 4.7 <_static/api.html?version=v4.7>`_

* `version 4.6 <_static/api.html?version=v4.6>`_

* `version 4.5 <_static/api.html?version=v4.5>`_

* `version 4.4 <_static/api.html?version=v4.4>`_

* `version 4.3 <_static/api.html?version=v4.3>`_

* `version 4.2 <_static/api.html?version=v4.2>`_

* `version 4.1 <_static/api.html?version=v4.1>`_

* `version 4.0 <_static/api.html?version=v4.0>`_

* `version 3.4 <_static/api.html?version=v3.4>`_

* `version 3.3 <_static/api.html?version=v3.3>`_

* `version 3.2 <_static/api.html?version=v3.2>`_

* `version 3.1 <_static/api.html?version=v3.1>`_
